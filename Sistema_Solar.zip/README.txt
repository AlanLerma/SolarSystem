SISTEMA SOLAR:

Indicaciones
1.- Abrir Sistema_Solar.pde
2.- Ejecutar c�digo
3.- Mueva la nave a trav�s del espacio con
    el rat�n, utilizando clik derecho e izquierdo
    para controlar la profundidad, y el sensor 
    para controlar su espaciado.